from copy import deepcopy
class Queue:


    """
    Practice Creating the Stack Class.

    Refresher: Stacks use First in First out. Where the main functions are insert(), remove(), and peak()
    """

    def __init__(self):
        """
        Create a blank list of values for the class to be used.

        """

        return

    def insert (self,value):
        """
        Insert value, at rear of Queue.
        """


        return


    def remove (self, key):
        """
        Remove value which matches key
        :return: the value.
        """


        return value
    
    def peak (self):
        """
        Returns a copy of the first value in que without removing it
        :return: copy of value
        """
        
        
        return value